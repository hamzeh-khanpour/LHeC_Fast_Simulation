#!/bin/sh
# **********************************************************************
# * setup    Program Library Installlation ENVironment                 *
# *                                                                    *
# * Garren     6/17/97 Configured for stdhep                           *
# **********************************************************************
 
unset PDG_MASS_TBL
unset Space
unset Phase
