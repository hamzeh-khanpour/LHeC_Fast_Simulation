/***  XDR manager code for dbin database I/O  ***/
/***  Generated automatically using the dbin tool. */
/***  Not to be modified by user. */
#include "mcf_ntubldXDRinc.h"
static int i;

